data(MC18)
data(MC15)
mix1 <- DNAmixture(MC18, k = 4, K = c("K3", "K2"), C = 38)
mix2 <- DNAmixture(MC15, k = 3, K = c("K3", "K1"), C = 50)
p1 <- list(rho=20,eta=20,xi=0.09, phi=c(K2=0.1,K3=0.1,U1=0.4,U2=0.4))
p2 <- list(rho=30,eta=30,xi=0.08, phi=c(K1=0.5,K3=0.1,U1=0.4))

## Traces with completely different parameters
system.time(
  out <- multipleTracesML(list(mix1, mix2), list(p1, p2), trace = T)
)

## Compare to individual analysis
system.time(outM1 <- maxlogL(mix1, p1))
system.time(outM2 <- maxlogL(mix2, p2))

## The individual analyses are faster than the combined, it seems.
out$minimization.output$n.funeval
outM1$minimization.output$nfuneval + outM2$minimization.output$n.funeval

## Now let scale and stutter be equal for the 2 traces.
constr2 <- function(x){
  etadiffs <- diff(unlist(x[,"eta"]))
  xidiffs <- diff(unlist(x[,"xi"]))
  c(etadiffs, xidiffs)
}
system.time(out2 <- multipleTracesML(list(mix1, mix2), list(p1, p2), constr2, val = c(0,0), trace=T))

## We can also let all the parameters be equal:
mix1e <- DNAmixture(MC18, k = 3, K = c("K3", "K2"), C = 38)
mix2e <- DNAmixture(MC15, k = 3, K = c("K2", "K3"), C = 50)
pe <- list(rho=30,eta=30,xi=0.08, phi=c(K2=0.1,K3=0.1,U1=0.8))
constr.all.eq <- function(x){
  rhodiffs <- diff(unlist(x[,"rho"]))
  etadiffs <- diff(unlist(x[,"eta"]))
  xidiffs <- diff(unlist(x[,"xi"]))
  ## Phi needs to be ordered when taking diffs
  phis <- x[,"phi"]
  phidiffs <- phis[[1]] - phis[[2]][names(phis[[1]])]
  ## remove one of the constraints on phi as this is redundant (phi sums to 1)
  c(rhodiffs, etadiffs, xidiffs, phidiffs[-1])
}
## there are 5 constraints: 6 parameters for the model,
## whereof one is redundant, and two models to compare.
system.time(out.all.eq <- multipleTracesML(list(mix1e, mix2e),
                                           list(pe, pe),
                                           constr.all.eq, val = rep(0,5), trace=T))
