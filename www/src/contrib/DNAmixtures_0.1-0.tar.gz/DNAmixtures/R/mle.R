##' Maximisation of the likelihood for one or more mixed traces of DNA
##'
##' @details The fixed constraints for the model are
##' \describe{
##' \item{xi}{in [0,1].}
##' \item{rho}{ in [0, Inf].}
##' \item{eta}{ in [0, Inf].}
##' \item{phi}{in [0, 1], sums to 1 and if 2 or more unknowns then the mixture
##' proportions for the unknown contributors are ordered decreasingly
##' with the first trace determining the order.}
##' }
##' If, say, equal xi's
##' are desired we can introduce constraints xi[1]-xi[2] = 0, etc.
##' @param mixture A \code{\link{DNAmixture}} object.
##' @param pars A \code{\link{mixpar}} parameter used as a starting value for the optimisation.
##' @param constraints Equality constraint function as function of an array of parameters.
##' @param phi.eq Should the mixture proportions be the same for all
##' traces? Defaults to FALSE.
##' @param val Vector of values to be satisfied for the equality constraints.
##' @param trace Print the evaluations of the likelihood-function during optimisation?
##' @param ... Further arguments to be passed on to \code{\link[Rsolnp]{solnp}}.
##' @return A list containing
##'    \item{mle}{The (suggested) MLE.}
##'    \item{lik}{The log of the likelihood (log e).}
##' as well as the output from the optimisation.
##' @author Therese Graversen
##' @export
##' @examples
##' \dontrun{
##' data(MC15, MC18, USCaucasian)
##' mix <- DNAmixture(list(MC15, MC18), C = list(50, 38), k = 3, K = "K1", database = USCaucasian)
##' startpar <- mixpar(rho = list(24, 25), eta = list(37, 40), xi = list(0.08, 0.1),
##'                    phi = list(c(U1 = 0.05, K1 = 0.7, U2 = 0.25),
##'                                 c(K1 = 0.7, U2 = 0.1, U1 = 0.2)))
##' eqxis <- function(x){ diff(unlist(x[,"xi"])) }
##' ## Note that for these two traces, we do not expect phi to be equal.
##' ## Here we set stutter equal for all traces
##' ml.diff <- mixML(mix, startpar, eqxis, val = 0, trace = TRUE, phi.eq = FALSE)
##' ## Equal mixture proportions across traces
##' ml.eqphi <- mixML(mix, startpar, eqxis, val = 0, trace = TRUE, phi.eq = TRUE)
##' }
##' @seealso \code{\link{DNAmixture}}
mixML <- function(mixture, pars, constraints = NULL, phi.eq = FALSE, val = NULL, trace = FALSE,
                           ...){
  R <- mixture$ntraces
  k <- mixture$k
  U <- mixture$U
  K <- mixture$K
  contr <- c(U, K)
  n.unknown <- mixture$n.unknown

  ## Return the list of (named) phis
  x2phi <- function(x){
    ## list with one phi per trace
    if (phi.eq){
      phi <- rep(list(tail(x, -3*R)), R)
    } else {
      phi <- split(tail(x, -3*R), rep(1:R, each = k))
    }
    ## Adding names of contributors to each phi
    mapply(function(th, contributor){names(th) <- contributor; th},
           phi, rep(list(contr), times=R), SIMPLIFY = FALSE)
  }

  ## Return only phi_U for each trace
  x2phiU <- function(x){
    ## Using indexing to cut out phi_U for each trace (inefficient...)
    ## mapply(function(th, u){th[u]}, x2phi(x), rep(list(U), each = R), SIMPLIFY=FALSE)
    
    ## List with phi_U for each trace
    lapply(x2phi(x), function(th){head(th, n.unknown)})
  }

  ## vector --> parameter; i.e. array of lists: rows = traces, columns = parameters
  x2arr <- function(x){
    arr <- array(list(NULL), dim = c(R, 4), dimnames = list(NULL, c("rho", "eta", "xi", "phi")))
    arr[1:(3*R)] <- as.list(head(x, 3*R))
    arr[,"phi"] <- x2phi(x)
    arr
  }

#    parlist2x <- function(pars){
#    ## Using only the specified phi for the first trace.
#    c(unlist(pars[,1:3],use.names=FALSE), pars[[1,"phi"]][contr])
#  }

  ## parameter --> vector
  parlist2x <- function(parlist){
    rex <- unlist(parlist[,1:3], use.names = FALSE)
    if (phi.eq){
      phi <- parlist[[1,4]][contr] ## phi for trace 1
    } else {
      phi <- unlist(lapply(parlist[,4], function(x)x[contr]), use.names = FALSE) ## phi for trace 1
    }
    c(rex, phi)
  }
  
  ## loglikelihood function
  logl <- logL(mixture)

  ## combined likelihood
  funvals <- numeric(0) ## only used if tracing.
  minus.loglikelihood <- function(x){
    xs <- x2arr(x)
    ## print(xs)
    val <- -logl(xs)
    if (trace){
      for (i in 1:R){
        print(unlist(xs[i,]))
      }
      funvals <<- c(funvals,val)
      print(val)
    }
    val
  }

  ## Parameter boundaries
  lb <- rep(0, times = 3*R + ifelse(phi.eq, k, k*R))
  ub <- rep(c(Inf, 1), times = c(2*R, R + ifelse(phi.eq, k, k*R)))
  
  ## Returning a vector containing the sums for each phi
  if (phi.eq){
    phi.sum.constraint <- function(x){
      sum(tail(x, -3*R))
    }
    eqB <- 1
  }
  else {
    phi.sum.constraint <- function(x){
      sapply(x2phi(x), sum)
    }
    eqB <- rep(1, R)
  }
  
  if (!missing(constraints)){
    eqfun <- function(x){c(phi.sum.constraint(x), do.call(constraints, list(x2arr(x))))}
    eqB <- c(eqB, val)
  } else {
    eqfun <- phi.sum.constraint
  }

  ## for traces with 2 or more unknowns, need to order their contribution
  ## -- note that all traces have the same number of unknowns here.  
  if (n.unknown > 1){
    ## Order just the first (or only) phi
    phi.symmetry <- function(x){
      phiU <- x2phiU(x)[[1]] ## Irelevant to sort as [U]?
      diff(phiU, lag = 1)
    }
    n.diffs <- (n.unknown - 1) ##*R
    ineqLB <- rep(-1, n.diffs)
    ineqUB <- rep(0, n.diffs)    
  }
  else phi.symmetry <- ineqLB <- ineqUB <- NULL
  
  ## Startvalue for the minimisation
  x0 <- parlist2x(pars)

  soln <- solnp(x0, fun = minus.loglikelihood,
                LB = lb, UB = ub,
                eqfun = eqfun, eqB = eqB,
                ineqfun = phi.symmetry,
                ineqLB = ineqLB, ineqUB = ineqUB,
                ...
                )
  
  est <- x2arr(soln$pars)
  val <- -tail(soln$value, 1)
  out <- list(mle = est, lik = val,
              funvals = funvals,
              starting.point = x0, 
              minimization.output = soln)
}

mixML_eqphis <- function(mixture, pars, constraints = NULL, val = NULL, trace = FALSE, ...){
  R <- mixture$ntraces
  k <- mixture$k
  U <- mixture$U
  K <- mixture$K
  contr <- c(U, K)
  n.unknown <- mixture$n.unknown

  ## Return the list of (named) phis
  x2phi <- function(x){
    phi <- rep(list(tail(x, -3*R)), R)
    mapply(function(th, contributor){names(th) <- contributor; th}, phi, rep(list(contr), times=R), SIMPLIFY = FALSE)
  }

  ## Return only phi_U for each trace
  x2phiU <- function(x){
    mapply(function(th, u){th[u]}, x2phi(x), rep(list(U), each = R), SIMPLIFY=FALSE)
  }

  ## Return an array of lists: rows = traces, columns = parameters
  x2arr <- function(x){
    arr <- array(list(NULL), dim = c(R, 4), dimnames = list(NULL, c("rho", "eta", "xi", "phi")))
    arr[1:(3*R)] <- as.list(head(x, 3*R))
    arr[,"phi"] <- x2phi(x)
    arr
  }

  parlist2x <- function(parlist){
    ## Using only the specified phi for the first trace.
    c(unlist(parlist[,1:3],use.names=FALSE), parlist[[1,"phi"]][contr])
  }
  
  ## loglikelihood 
  logl <- logL(mixture)

  ## combined likelihood
  funvals <- numeric(0) ## only needed if tracing.
  minus.loglikelihood <- function(x){
    xs <- x2arr(x)
    val <- -logl(xs)
    if (trace){
      for (i in 1:R){
        print(unlist(xs[i,]))
      }
      funvals <<- c(funvals, val)
      print(val)
    }
    val
  }
  
  ## Phi sums to 1
  phi.sum.constraint <- function(x){
    sum(tail(x, -3*R))
  }
  
  if (!missing(constraints)){
    eqfun <- function(x){c(phi.sum.constraint(x), do.call(constraints, list(x2arr(x))))}
    eqB <- c(1, val)                    ## nothing assures that this is specified.
  } else {
    eqfun <- phi.sum.constraint
    eqB <- 1
  }

  ## for traces with 2 or more unknowns, need to order their contribution
  ## For multiple traces, all have the same number of contributors...
  if (n.unknown > 1){
    phi.symmetry <- function(x){
      ## phiU <- x2phiU(x)[n.unknown > 1]
      ## print(sapply(phiU, diff, lag=1))
      ## sapply(phiU, diff, lag=1)
      phiU <- x2phiU(x)[[1]][U]
      diff(phiU, lag = 1)
    }
    n.diffs <- n.unknown - 1
    ineqLB <- rep(-1, n.diffs)
    ineqUB <- rep(0, n.diffs)    
  } else phi.symmetry <- ineqLB <- ineqUB <- NULL

  lb <- rep(0, times = 3*R + k)
  ub <- rep(c(Inf, 1), times = c(2*R, R+k))

  x0 <- parlist2x(pars)

  soln <- solnp(x0, fun = minus.loglikelihood,
                LB = lb, UB = ub,
                eqfun = eqfun, eqB = eqB,
                ineqfun = phi.symmetry,
                ineqLB = ineqLB, ineqUB = ineqUB,
                control = list(trace = 1)
                )
  
  est <- x2arr(soln$pars)
  val <- -tail(soln$value, 1)
  out <- list(mle = est, lik = val,
              funvals = funvals,
              starting.point = x0, 
              minimization.output = soln)
}
