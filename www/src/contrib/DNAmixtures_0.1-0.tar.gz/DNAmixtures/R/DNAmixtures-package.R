##' Statistical Inference for Mixed Traces of DNA
##'
##' Tools for statistical inference about contributors to one or more
##' mixed traces of DNA.
##'
##' @details The package implements a statistical model for analysis
##' of mixed traces of DNA with artefacts such as dropout and stutter.
##' In theory, the implementation allows analysis with an arbitrary
##' number of unknown contributors. However, in practice, depending on
##' hardware and time-constraints working with up to 5 or 6 unknown
##' contributors seems realistic.
##'
##' @section Summary of the model implemented:
##' Genotypes for unknown contributors are modelled using allele-frequencies from a database specified by the user. 
##' 
##' The peak heights are modelled using gamma distributions with the peak for allele a having shape parameter
##' \deqn{\rho(1-\xi_a)\sum_a n_{ia}\phi_i + \rho \xi_{a+1}\sum_a n_{ia+1}\phi_i}
##' where \eqn{n_{ia}} denotes the number of alleles of type a for contributor i.
##' Peaks below the detection threshold C are recorded with height 0.
##' 
##' The model parameters are for each DNA mixture
##' \describe{
##' \item{phi}{The proportions of DNA from each contributor.}
##' \item{rho}{Amplification parameter, which will be larger for larger amounts of DNA amplified.}
##' \item{eta}{Scale parameter for the gamma distribution.}
##' \item{xi}{Stutter parameter. Allele a has stutter \eqn{\xi_a = \xi} or \eqn{\xi_a = 0}, depending on whether or not the allele can stutter.}
##' }
##' 
##' Note that the parameter \eqn{\theta} has been renamed to
##' \eqn{\phi} to follow the paper describing the implemented
##' statistical model (http://arxiv.org/abs/1302.4404). This was
##' originally done to avoid conflict of notation with the
##' \eqn{\theta}-correction. A change of notation in present package
##' is likely in the future.

##'
##' The model assumes the model parameters to be the same across
##' markers.  Relaxations of these assumptions are possible, but are
##' not implemented here.
##' 
##' An alternative parametrisation uses \eqn{\mu = \rho \eta} and
##' \eqn{\sigma = 1/\sqrt{\rho}}, which can be interpreted as the mean
##' peak height and the coefficient of variation respectively. Another
##' advantage of this reparametrisation is that the parameters are
##' fairly orthogonal.
##'
##' Importantly, note that \code{DNAmixture} when given a list of
##' traces will assign the same set of contributors to all mixed
##' profiles analysed, but also that this actually covers all possible
##' models. This is because a contribution-proportion of 0 corresponds
##' to "not having contributed".
##'
##' @section Computation by auxiliary variables: The workhorses of
##' this package are the functions \code{\link{set.CPT.O}},
##' \code{\link{set.CPT.D}} and \code{\link{set.CPT.Q}} for setting
##' the conditional probability tables on binary nodes. For details,
##' see the forthcoming DPhil thesis of Therese Graversen.
##'
##' Note that if invalid tables are set -- for instance if very extreme
##' parameter values are used -- then any subsequent propagation will
##' fail. No roll-back functionality has so far been implemented to
##' fix this, and the easiest solution is to re-fit the mixture model.
##'
##' @section Amelogenin: As an experiment, it is possible to add the
##' marker Amelogenin, provided that the marker is named as "AMEL" and
##' that the coding of alleles X and Y is of a particular form. One
##' example of a suitable form is the coding X = 0 and Y = 1. The
##' allele frequencies used should then also contain a marker "AMEL",
##' and here frequencies have a slightly different interpretation than
##' for the rest of the markers: As all people possess one X, the
##' frequencies of X and Y denote the presence of an additional X or Y
##' respectively, and thus the frequencies correspond directly to the
##' proportions of the two genders.
##'
##' @name DNAmixtures-package
##' @aliases DNAmixtures
##' @docType package
##'
##' @author Therese Graversen
##' 
##' Maintainer: Therese Graversen \email{therese.graversen@@stats.ox.ac.uk}
##' 
##' @seealso \code{\link[RHugin]{RHugin}}
##' @references Details on the implemented model will be available in
##' the forthcoming Ph.d. thesis by Therese Graversen and can also be
##' found at \url{http://arxiv.org/abs/1302.4404}.
##' 
##' @example examples/main.R
NULL
