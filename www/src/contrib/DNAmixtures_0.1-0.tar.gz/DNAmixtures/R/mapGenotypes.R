##' Maximum posterior genotypes of unknown contributors
##'
##' For each marker, an list of configurations of genotypes for some
##' or all unknown contributors is returned. The list contains all
##' configurations with posterior probability higher than some
##' specified \code{pmin}. 
##'
##' @details 
##' Note that an error occurs the specified cutoff is lower than the
##' highest posterior probability.
##'
##' @param mixture a DNA mixture
##' @param pmin Minimum probabilities 
##' @param U The unknown contributors named by an integer vector
##' @param markers Character vector of marker names
##' @param type Currently one of
##' \describe{
##' \item{seen}{Alleles that are seen in at least one EPG}
##' \item{all}{All alleles}
##' \item{unseen}{Alleles that are not seen in any EPG (possibly redundant)}
##' }
##' @return A list, which for each marker contains the maximum
##' posterior configurations of genotypes above the specified probabilities \code{pmin}.
##' @export
##' @examples
##' data(MC18, USCaucasian, SGMplusDyes)
##' mix <- DNAmixture(list(MC18), k = 3, K = "K1", C = list(50), database = USCaucasian)
##' parameters(mix) <- mixpar(rho = list(30), eta = list(30), xi = list(0.07), phi = list(c(K1 = 0.7, U1 =0.2, U2 = 0.1)))
##' ## Jointly best for all unknown contributors
##' mp <- map.genotypes(mix, pmin = 0.01, type = "seen") 
##' summary(mp) ## Profiles as genotypes rather than allelecounts
##' ## Marginally best for contributor U1
##' mpU1 <- map.genotypes(mix, pmin = 0.01, U = 1, type = "seen", markers = "D16S539") 
##' summary(mpU1)
map.genotypes <- function(mixture, pmin,
                          U = seq_along(mixture$U), ## numeric index, not the names U1 etc
                          markers = mixture$markers, ## vector of marker-names
                          type = c("seen", "all", "unseen")
                          ){

  if (mixture$n.unknown == 0) stop("There are no unknown genotypes to predict")
  
  pmin <- rep(pmin, length.out = length(markers))
  if (!all(U < mixture$n.unknown)){"Invalid contributors"}
  type <- match.arg(type)
  
  getProbs <- function(m){
    ## extract peak heights
    H <- mixture$data[[m]][, seq_len(mixture$ntraces) + 1, drop = FALSE]

    ## Choose alleles
    ind <- switch(type,
                  seen = which(rowSums(H)>0),
                  unseen = which(rowSums(H)==0),
                  all = seq_len(nrow(H)))
    
    d <- map.configurations(mixture$domains[[m]], 
                            attr(mixture$domains[[m]], "n")[ind, U], pmin = pmin[which(markers==m)])

    attr(d, "alleles") <- mixture$data[[m]]$allele[ind]
    d
  }
  out <- lapply(markers, getProbs)
  names(out) <- markers
  structure(out,
            U = U,
            pmin = pmin,
            ptotal = sapply(out, function(x)sum(x$Prob)),
            class = c("map.genotypes", "list")
            )
}

##' Summary of best genotypes
##'
##' The maximum posterior configurations of genotypes as returned by
##' \code{\link{map.genotypes}}, but in the format of pairs of alleles
##' rather than raw allelecounts. When a subset of alleles are
##' considered, then the value NA is used to denote an allele outside
##' this subset.
##' 
##' @S3method summary map.genotypes
##' @method summary map.genotypes
##' @param object An object returned by \code{\link{map.genotypes}}.
##' @param ... not used.
##' @return A \code{data.frame} with two columns per contributor and a
##' column \code{Prob} containing the probability of the
##' configuration.
##' @seealso \code{\link{map.genotypes}}
##' @author Therese Graversen
##' @export
summary.map.genotypes <- function(object, ...){

  extractGenotype <- function(dat){
    alleles <- attr(dat, "alleles") 
    vec <- rep(seq_along(attr(object, "U")), each = length(alleles))
    mat <- matrix(NA, nrow = nrow(dat), ncol = 2*length(attr(object, "U")))
    for (i in 1:nrow(dat)){
      r <- split(head(as.numeric(dat[i,]), -1), vec)
      for (j in seq_along(attr(object, "U"))){
        mat[i, 2*(j-1) + 1:2] <- rep(c(alleles, NA), times = c(r[[j]], 2-sum(r[[j]])))
      }
    }
    mat <- as.data.frame(mat)
    names(mat) <-  paste0("U", rep(attr(object, "U"), each = 2), ".", 
                          rep(1:2, times = length(attr(object, "U"))))
    mat$Prob <- dat$Prob
    mat
  }
  out <- lapply(object, extractGenotype)

  structure(out,
            class = c("summary.map.genotypes", "list"),
            U = attr(object, "U"),
            pmin = attr(object, "pmin"),
            ptotal = attr(object, "ptotal")
            )
}

##' @S3method print summary.map.genotypes
##' @method print summary.map.genotypes
##' @rdname summary.map.genotypes
##' @param x An object returned by \code{summary.map.genotypes}.
##' @export
print.summary.map.genotypes <- function(x, ...){
  for (i in 1:length(x)){
    cat("\n",names(x)[[i]], ":\n", sep = "")
    print(as.data.frame(do.call(cbind, c(lapply(subset(x[[i]], select=-Prob), format, drop0trailing = TRUE),
                                         list(Prob = format(x[[i]]$Prob, digits=4))))), right = FALSE, quote=FALSE,
          print.gap = 3L, ...)
    cat("\nTotal probability:", format(attr(x, "ptotal")[i], digits = 4), "\n\n")
  }
}


