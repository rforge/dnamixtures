##' Various probabilities in a fitted DNA mixture model
##'
##' @details
##' For a mixture with unknown contributors, the probabilities are computed 
##' with respect to one of three distributions:
##' \describe{
##' \item{joint}{Default. No conditioning on observed peak heights.}
##' \item{conditional}{Condition on heights \eqn{Z_b} (via. \eqn{O_b}) for \eqn{b <= a}.}
##' \item{prequential}{Condition on heights \eqn{Z_b, b < a}.}
##' }
##' If all contributors are fixed, all distributions are the same
##' due to independence of the peak heights.
##'
##' @param object A \code{\link{DNAmixture}} object
##' @param pars Array of model parameters
##' @param markers The set of markers of interest
##' @param dist One of "joint", "conditional", and "prequential". If
##' there are only known contributors, these are all the same since, under the model, peak
##' heights are condtionally independent given profiles of the
##' contributors.
##' @param by.allele If \code{dist = "prequential"} then the order in
##' which we condition on traces and alleles matters. \code{by.allele
##' = TRUE} will proceed through alleles in increasing repeat number,
##' and for each allele condition on one trace at the time. If false,
##' the conditioning is done by traces and then alleles within these.
##' @param ... Not used
##' 
##' @return A list with one data.frame per marker containing various probabilities for
##' diagnostics
##' \item{unseen}{The probability of not seeing a peak, i.e. no peak or a peak falling below the threshold}
##' \item{seen}{The probability of seeing the allele}
##' \item{smaller}{The probability of seeing a smaller peak than the
##' one observed}
##' \item{larger}{The probability of seeing a larger
##' peak than the one observed}
##' @author Therese Graversen
##' @S3method predict DNAmixture
##' @method predict DNAmixture
##' @export
##' @examples 
##' data(MC15, MC18, USCaucasian)
##' mix <- DNAmixture(list(MC15, MC18), C = list(50,50), k = 3, K = c("K1", "K3", "K2"),
##' database = USCaucasian)
##' p <- mixpar(list(
##'                 list(rho = 30, eta = 30, xi = 0.08, phi = c(K2 = 0.1, K3 = 0.2, K1 = 0.7)),
##'                 list(rho = 3, eta = 30, xi = 0.08, phi = c(K2 = 0.4, K3 = 0.5, K1 = 0.1))))
##' predict(mix, p)
predict.DNAmixture <- function(object, pars, dist = c("joint", "conditional", "prequential"),
                               markers = object$markers, by.allele = TRUE, ...){
  observed <- object$observed
  
  if (object$n.unknown == 0){
    dist <- "known"
    all.shapes <- get.shapes(object, pars)
    eta <- unlist(pars[,"eta"])
    C <- unlist(object$C)
  }
  else {
    dist <- match.arg(dist)
    ## Note that tables are set on the global mixture object.
    CPTfactors <- set.cpt(object, pars) 
  }

  f.known <- function(m){
    traces <- object$observed[[m]]
    ## Inner loop will be traces, and outer loop will be alleles
    heights <- as.vector(t(object$data[[m]][,traces+1])) ## a column per trace
    shapes <- as.vector(all.shapes[[m]]) ## a column per trace
    alleles <- object$data[[m]][,1]

    cbind(
      rep(alleles, each = length(traces)),
      pgamma(C[traces], shape = shapes, scale = eta[traces], lower.tail = FALSE),
      pgamma(C[traces], shape = shapes, scale = eta[traces]),
      pgamma(heights, shape = shapes, scale = eta[traces], lower.tail = FALSE),
      pgamma(heights, shape = shapes, scale = eta[traces]),
      rep(traces, times = length(alleles)),
      heights
      )
  }
  
  f.joint <- function(m){
    domain <- object$domains[[m]]
    D <- attr(domain, "D")
    Q <- attr(domain, "Q")
    dat <- object$data[[m]]
    
    ## No conditioning on peak heights
    retract(domain, unlist(attr(domain, "O")))
    propagate(domain)

    out <- list()
    for (r in observed[[m]]){
      ds <- D[[r]]
      qs <- Q[[r]]
      out[[r]] <- do.call("rbind", lapply(seq_along(ds), function(a){
        c(dat$allele[a], get.belief(domain, ds[a]), get.belief(domain, qs[a]), r, dat[a,r+1])
      }))
    }
    do.call("rbind", out)
  }  
  
  f.conditional <- function(m){
    domain <- object$domains[[m]]
    D <- attr(domain, "D")
    Q <- attr(domain, "Q")
    O <- attr(domain, "O")
    dat <- object$data[[m]]
    
    ## strictly, we need only condition on O's, not multiply on the factors.
    ## Condition on all peak heights
    for (r in observed[[m]]){
      o <- O[[r]]
      cptfac <- CPTfactors[[m]][[r]]
      lapply(seq_along(unlist(o)), function(a)set.finding(domain, o[a], cptfac[,a]))
    }
    
    out <- list()
    for (r in observed[[m]]){
      out[[r]] <- do.call("rbind", lapply(seq_along(D[[r]]), function(a){
        retract(domain, O[[r]][a]) ## Remove conditioning on height[a]
        propagate(domain)
        set.finding(domain, O[[r]][a], CPTfactors[[m]][[r]][,a]) ## enter height[a] for D[a+1]
        ## Probabilities conditionally on height[b], b!=a
        c(dat$allele[a], get.belief(domain, D[[r]][a]), get.belief(domain, Q[[r]][a]), r, dat[a, r+1])
      }))
    }
    do.call("rbind", out)
  }

  f.prequential <- function(m){
    domain <- object$domains[[m]]
    D <- attr(domain, "D")
    O <- attr(domain, "O")
    Q <- attr(domain, "Q")
    dat <- object$data[[m]]
    
    ## No conditioning on peak heights (changes not yet propagated)
    retract(domain, unlist(attr(domain, "O")))
    
    f <- function(r, a){
      retract(domain, O[[r]][a]) ## Remove conditioning on height[a]
      propagate(domain)
      set.finding(domain, O[[r]][a], CPTfactors[[m]][[r]][,a]) ## enter height[a] for D[a+1]
      ## Probabilities conditionally on height[b], b!=a
      c(dat$allele[a], get.belief(domain, D[[r]][a]), get.belief(domain, Q[[r]][a]), r, dat[a,r+1])
    }

    out <- matrix(NA, length(observed[[m]])*length(dat$allele), 7)
    i <- 0
    if (by.allele){
      for (a in order(dat$allele)){
        for (r in observed[[m]]){
          i <- i+1
          out[i,] <- f(r,a)
        }
      }
    }
    else {
      for (r in observed[[m]]){
        for (a in order(dat$allele)){
          i <- i+1
          out[i,] <- f(r,a)
        }
      }
    }
    out
  }

  marker.probs <- switch(dist,
                         joint = f.joint,
                         conditional = f.conditional,
                         prequential = f.prequential,
                         known = f.known
                         )
  
  ## Return a list of data.frames
  out <- lapply(markers, function(m){
    d <- as.data.frame(marker.probs(m), stringsAsFactors = FALSE)
    names(d) <- c("allele", "seen", "unseen", "larger", "smaller", "trace", "height")
    d$marker <- m
    d
  })
  names(out) <- markers
  
  ## Note that evidence is left upon exit.
  out
}

