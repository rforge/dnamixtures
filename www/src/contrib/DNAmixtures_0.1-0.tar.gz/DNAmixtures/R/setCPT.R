##' Set CPT-s for all auxiliary variables
##'
##' A wrapper-function for the case where the conditional probability
##' tables are to be set in a DNA mixture model for all the auxiliary variables
##' (O, D and Q, at all markers and all alleles). 
##' 
##' The conditional probability tables are set according to a list of
##' specified parameters and the observed peak heights. Evidence will
##' be entered on the nodes O, as this is the behaviour of \code{\link{set.CPT.O}}.
##' The function returns evidence for future use on the nodes O.
##' 
##' @export
##' @param mixture A DNA mixture
##' @param pars A list of parameters
##' @return List containing evidence for conditioning on peak heights.
##' @author Therese Graversen
##' @seealso For further details see in particular \code{\link{set.CPT.O}}.
set.cpt <- function(mixture, pars){

  ## extract relevant stuff from mixture and pass on  
  C <- mixture$C
  k <- mixture$k
  K <- mixture$K
  U <- mixture$U
  n.unknown <- mixture$n.unknown
  observed <- mixture$observed 

  data <- mixture$data
  domains <- mixture$domains
    
  one.marker <- function(m){
    domain <- domains[[m]]
    d <- data[[m]]
    n_K <- subset(d, select = K)
    gs <- d$gets_stutter
    cs <- d$can_stutter
    sf <- d$stutter.from

    ev <- list()
    for (r in observed[[m]]){
      rho <- pars[[r,"rho"]]
      xi <- pars[[r,"xi"]]
      eta <- pars[[r,"eta"]]
      phi <- pars[[r,"phi"]][c(U, K)]  
      
      set.CPT.D(domain, rho, xi, eta, phi, C[[r]], n.unknown,
                n_K, attr(domain, "D")[[r]], gs, cs, sf)
      
      set.CPT.Q(domain, rho, xi, eta, phi, d[,r+1], n.unknown,
                n_K, attr(domain, "Q")[[r]], gs, cs, sf)
      
      ev[[r]] <- set.CPT.O(domain, rho, xi, eta, phi, d[,r+1], C[[r]], n.unknown,
                           n_K, attr(domain, "O")[[r]], gs, cs, sf)
    }
    ev
  }
  evidence <- lapply(mixture$markers, one.marker)
  names(evidence) <- mixture$markers
  evidence
}

