##' Loglikelihood function for DNA mixture analysis.
##'
##' The log likelihood function for one or more traces of DNA
##' @param mixture A \code{\link{DNAmixture}} model.
##' @return The log likelihood function as a function of an array of model parameters.
##' @export
##' @author Therese Graversen
logL <- function(mixture){
  if (mixture$n.unknown > 0){
    logL.UK(mixture)
  }
  else {
    logL.K(mixture)
  }
}
  
##' @rdname logL
##' @export
logL.UK <- function(mixture){

  domains <- mixture$domains 

  ## (log)Normalising constants without any evidence on peak heights
  ## Usually these are theoretically 0 (in practice ~10^-16)
  bases <- sapply(mixture$domains, 
                  function(d){
                    retract(d, unlist(attr(d, "O")))
                    propagate(d)
                    get.normalization.constant(d, log = TRUE)
                  })
  
  function(pararray){
    C <- mixture$C
    n.unknown <- mixture$n.unknown
    U <- mixture$U
    K <- mixture$K
    n_K <- lapply(mixture$data, function(d)subset(d, select = K))

    logL.m <- function(m){
      
      ## marker specific values
      domain <- mixture$domains[[m]]
      d <- mixture$data[[m]]
      rho <- pararray[,"rho"]
      xi <- pararray[,"xi"]
      eta <- pararray[,"eta"]
      phi <- pararray[,"phi"]
      
      for (r in seq_len(mixture$ntraces)){
        if (!all(is.na(d[,r+1]))){ ## if some heights are observed at this marker
          ## Set CPTs using parameter values
          set.CPT.O(domain, rho[[r]], xi[[r]], eta[[r]], phi[[r]][c(U, K)],
                    d[,r+1], C[[r]], n.unknown, n_K[[m]], attr(domain, "O")[[r]],
                    d$gets_stutter, d$can_stutter, d$stutter.from)
        }
      }
      ## Propagate and get new log-normalizing constant
      propagate(domain)
      get.normalization.constant(domain, log = TRUE)
    }
    
    ## Add up contributions from the M markers
    sum(sapply(seq_along(domains), logL.m) - bases)
  }
}


##' @export
##' @rdname logL
logL.K <- function(mixture){

  domains <- mixture$domains
  C <- mixture$C
  k <- mixture$k
  data <- mixture$data
  n_K <- lapply(data, function(d)subset(d, select = mixture$K))

  function(pars){
    rhos <- pars[,"rho"]
    etas <- pars[,"eta"]
    xis <- pars[,"xi"]
    phis <- pars[,"phi"]
    
    logL.m <- function(m){
      ## marker specific values
      d <- data[[m]]
      heights <- d[,seq_len(mixture$ntraces) + 1, drop = FALSE]
      can_stutter <- d$can_stutter
      gets_stutter <- d$gets_stutter
      stutter.from <- d$stutter.from
      n_K <- as.matrix(n_K[[m]])
      
      one.allele <- function(a){

        one.trace <- function(rho, eta, xi, phi, height, threshold){

          ## As not all traces might have this allele:
          if (is.na(height)){return(0)}
          
          shape <- rho * (1 - xi*can_stutter[a]) * (n_K[a,] %*% phi)
          if (gets_stutter[a]){
            st <- stutter.from[a]
            ## can_stutter[st] = TRUE necessarily
            shape <- shape + rho * xi * (n_K[st,] %*% phi)
          }
          shape <- as.numeric(shape)

          ## likelihood for trace r, allele a
          if (height == 0)
            pgamma(threshold, shape = shape, scale = eta, log.p = TRUE)
          else
            dgamma(height, shape = shape, scale = eta, log = TRUE)
        }
        ## sum over traces, to get likelihood for allele a
        sum(mapply(FUN = one.trace, rhos, etas, xis, phis, heights[a,], C,
                   SIMPLIFY = TRUE))
      }
      ## sum over alleles, to get likelihood for marker m
      sum(sapply(seq_len(nrow(d)), one.allele))
    }
    ## sum over markers, to get overall likelihood
    sum(sapply(seq_along(mixture$markers), logL.m))    
  }
}
