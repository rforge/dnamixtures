##' Parameters for DNA mixture models
##'
##' @return \code{mixpar} returns an object of class "mixpar".
##' @author Therese Graversen
##' @export
##' @param rho Amplification factor.
##' @param eta Scale parameter in the gamma distribution.
##' @param xi Stutter parameter.
##' @param phi Named vector of the fraction of DNA contributed by each contributor.
##' @param parlist A list of parameters
##' @examples
##' q <- mixpar(rho = list(30, 30), eta = list(30, 30), xi = list(0.08, 0.08),
##' phi = list(c(Anna = 0.5, Peter = 0.2, U1 = 0.3), c(Christian = 0.5, Peter = 0.2, U1 = 0.3)))
##' ## Equivalent to
##' p1 <- mixpar(rho = list(30), eta = list(30), xi = list(0.08), phi = list(c(Anna = 0.5, Peter = 0.2, U1 = 0.3)))
##' p2 <- mixpar(rho = list(30), eta = list(30), xi = list(0.08), phi = list(c(Christian = 0.5, Peter = 0.2, U1 = 0.3)))
##' p <- mixpar(list(p1, p2))
mixpar <- function(parlist = NULL, rho = NULL, eta = NULL, xi = NULL, phi = NULL){

  if (!missing(parlist)){
    rho <- lapply(parlist, "[[", "rho")
    eta <- lapply(parlist, "[[", "eta")
    xi <- lapply(parlist, "[[", "xi")
    phi <- lapply(parlist, "[[", "phi")
  }

  arr <- array(list(), dim = c(length(rho), 4), dimnames = list(NULL, c("rho", "eta", "xi", "phi")))

  arr[,1] <- rho
  arr[,2] <- eta
  arr[,3] <- xi
  arr[,4] <- phi
  structure(arr,            
            class = "mixpar")
}

##' Print a parameter for a DNA mixture model
##'
##' @param x The model parameter
##' @param ... Not used
##' @S3method print mixpar
##' @method print mixpar
##' @return invisibly the mixture parameter x.
##' @author Therese Graversen
print.mixpar <- function(x, ...){
  for (i in 1:dim(x)[1])
    print.default(unlist(x[i,]), print.gap = 2L)
  invisible(x)
}

##' Set or extract the parameters of a DNA mixture.
##'
##' Note that setting the parameters of the DNA mixture also
##' conditions on the observed peak heights.
##'
##' @export
##' @param mixture A \code{\link{DNAmixture}}
##' @export
parameters <- function(mixture){
  mixture$parameters
}

##' @export
##' @rdname parameters
##' @usage parameters(mixture) <- value
##' @param value A \code{mixpar} model parameter.
"parameters<-" <- function(mixture, value){

  stopifnot(class(mixture) == "DNAmixture")

  mixture$parameters <- value
  if (mixture$n.unknown > 0){
    ## Set tables for O, D, Q and (not propagated) evidence for O.
    ## and store the evidence for easy conditioning 
    mixture$CPTfactors <- set.cpt(mixture, pars = value)
    ## Propagate
    lapply(mixture$domains, propagate)
  }
  else {
    ## store the shapes for the gamma distributions
    mixture$shapes <- get.shapes(mixture, value)
  }
  mixture
}

##' Including or excluding peak height information.
##' 
##' Condition on or retract information about all peak heights.
##'
##' @note Requires model parameters to be set.
##'
##' @param mixture A DNAmixture object.
##' @param cond Condition on (all) observed peak heights? Propagate
##' evidence (TRUE) or retract all evidence (FALSE) on all O-nodes.
##' @param markers The set of markers for which the conditioning on peak heights should be done.
##' @author Therese Graversen
##' @examples 
##' data(MC15, MC18, USCaucasian)
##' mix <- DNAmixture(list(MC15, MC18), C = list(50, 38), k = 3, K = c("K1", "K3"),
##'                    database = USCaucasian)
##' p <- mixpar(list(list(rho = 30, eta = 30, xi = 0.08, phi = c(U1 = 0.1, K3 = 0.2, K1 = 0.7)),
##'                 list(rho = 30, eta = 30, xi = 0.08, phi = c(U1 = 0.1, K3 = 0.2, K1 = 0.7))))
##' ## Set parameters and condition on peak heights
##' parameters(mix) <- p   
##' condPeakHeights(mix, FALSE) ## No conditioning on peak heights
##' get.belief(mix$domains$VWA, "n_1_2")
##' condPeakHeights(mix, TRUE)  ## Condition on peak heights
##' get.belief(mix$domains$VWA, "n_1_2")
##' @export
condPeakHeights <- function(mixture, cond, markers = mixture$markers){
  if(any(mixture$n.unknown == 0, is.null(mixture$CPTfactors)))
    stop("CPTs have not been set for the auxiliary variables")
  
  for (m in markers){
    domain <- mixture$domains[[m]]
    O <- attr(domain, "O")                 ## list of O-nodes (possibly empty) for each trace
    CPTfactors <- mixture$CPTfactors[[m]]  ## list of scalingfactors (possibly empty) for each trace
    
    if (cond){ ## Set evidence
      for (r in mixture$observed[[m]]){
        lapply(seq_along(O[[r]]), function(a){
          set.finding(domain, O[[r]][a], CPTfactors[[r]][,a])
        })}
    }
    else { ## Retract evidence
      retract(domain, unlist(O))
    }
    ## propagate the changes
    propagate(domain)
  }

  invisible(NULL)
}
