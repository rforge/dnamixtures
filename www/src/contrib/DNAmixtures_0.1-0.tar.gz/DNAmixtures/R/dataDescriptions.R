##' @name MC18
##' @title The MC18 DNA trace
##' @description Peak heights from analysis of a bloodstain with DNA
##' from an unknown number of contributors. There are three reference
##' profiles K1, K2, and K3. 
##' @docType data
##' @format A \code{data.frame}.
##' @source Peter Gill et. al. (2008)
##' \emph{Interpretation of complex {DNA} profiles using empirical models and a method to measure their robustness}.
##' Forensic Science International: Genetics, 2(2):91--103.
NULL

##' @name MC15
##' @title The MC15 DNA trace
##' @description Peak heights from analysis of a bloodstain with DNA
##' from an unknown number of contributors.  There are three reference
##' profiles K1, K2, and K3. 
##' @docType data
##' @format A \code{data.frame}
##' @source Peter Gill et. al. (2008)
##' \emph{Interpretation of complex {DNA} profiles using empirical models and a method to measure their robustness}.
##' Forensic Science International: Genetics, 2(2):91--103.
NULL

##' @name USCaucasian
##' @title The data base of allele frequencies for 302 US Caucasian profiles.
##' @docType data
##' @description Note that there are some errata found after
##' publication, which are not corrected here. The frequencies also
##' did not add up to 1, and this is simply corrected by normalising
##' within each marker.
##' @format A \code{data.frame} with, for each marker,
##' the set of possible alleles as well as their corresponding frequency.
##' @source \url{http://www.cstl.nist.gov/strbase/NISTpop.htm}
NULL

##' @name UKCaucasian
##' @title Allele frequencies for UK Caucasians
##' @docType data
##' @description Database of allele frequencies for UK Caucasians.
##' @format A \code{data.frame}
##' @source The frequencies are produced from the allele counts for
##' one (the UK Caucasian) of three British sub-populations as found
##' on David Balding's homepage under his LTD software for mixture
##' analysis in R \url{https://sites.google.com/site/baldingstatisticalgenetics/software/likeltd-r-forensic-dna-r-code}.
NULL

##' @name NGM
##' @title NGM allele frequencies
##' @docType data
##' @description NGM allele frequencies. 
##' @format A list containing
##' \describe{
##' \item{USCaucasian}{\code{data.frame} with, for each marker,
##' the set of possible alleles as well as their corresponding frequency.}
##' }
##' @source Budowle et. al (2011) \emph{Population Genetic Analyses of the NGM STR loci}.
##' International Journal of Legal Medicine, 125(1):101-109.
NULL

##' @name SGMplusDyes
##' @title Dyes used for SGMplus
##' @docType data
##' @description Dyes used for the AmpFlSTR SGM Plus PCR Amplification Kit
##' @source Applied Biosystems
##' @format A list.
NULL

##' @name ProfilerDyes
##' @title Dyes used for Profiler plus
##' @docType data
##' @description Dyes used for the AmpFlSTR Profiler Plus PCR Amplification Kit
##' @source Applied Biosystems
##' @format A list.
NULL

##' @name NGMDyes
##' @title Dyes used for NGM
##' @docType data
##' @description Dyes used for the AmpFlSTR NGM PCR Amplification Kit
##' @source Applied Biosystems
##' @format A list.
NULL
