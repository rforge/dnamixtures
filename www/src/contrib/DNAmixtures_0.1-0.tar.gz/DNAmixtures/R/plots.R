##' Plot a DNA mixture model
##'
##' Plot of peak heights against repeat numbers for each marker. 
##'
##' @export
##' @method plot DNAmixture
##' @S3method plot DNAmixture
##' @param x A DNA mixture with multiple traces
##' @param traces Indices giving the traces, for which plots should be made.
##' @param markers Vector of names giving the markers, for which plots should be made.
##' @param plot.type To be described.
##' @param pw Peaks are 2*pw wide.
##' @param threshold Should the detection thresholds be indicated on the plot?
##' @param add Add to existing plot? (not meaningful if \code{plot.type = "epg"}.)
##' @param panel Alternative function for drawing the peaks. For
##' instance \code{lines} can be used for making triangular peaks. This functionality will be removed.
##' @param ... Other parameters to be passed on to \code{plot}
##' @return A data.frame containing the plotted data points.
##' @examples
##' data(MC15, MC18, USCaucasian, SGMplusDyes)
##' mix <- DNAmixture(list(MC15, MC18), C = list(50,50), k = 3, K = c("K1", "K3"), database = USCaucasian)
##' dyes(mix) <- list(SGMplusDyes, SGMplusDyes)
##' plot(mix)
plot.DNAmixture <- function(x, traces = seq_len(x$ntraces), markers = x$markers,
                            plot.type = c("all", "individual", "epg"),
                            pw = 0.4, threshold = TRUE, panel = NULL,
                            add = FALSE, ...){
  
  ## Number of traces
  if (any(traces > x$ntraces))stop("The specified traces are invalid")

  ## Type of plot
  plot.type <- match.arg(plot.type)
  
  ## largest peak amongst those we are plotting
  maxheight <- max(sapply(x$data[markers], function(d)max(d[,traces+1, drop = FALSE])), na.rm = TRUE)
  
  peakPoints <- function(alleles, heights){    
    ## Treating all markers as having 4 bp repeats.
    alleles <- floor(alleles) + 2.5* (alleles - floor(alleles))
    xs <- as.vector(outer(c(-pw/4,0,pw/4), alleles, "+"))
    ys <- as.vector(rbind(0,heights,0))
    o <- order(xs)
    list(x = xs[o], y = ys[o], mid = alleles, height = heights)
  }

  ## plot information for *all traces*, not just the ones we plot
  pp <- lapply(x$data[markers], function(d){apply(d[,seq_len(x$ntraces)+1, drop = FALSE], 2, function(height)peakPoints(d$allele, height))})
  
  nicePeak <- function(a,b, ...){
    f <- function(t)3*t^2-2*t^3
    for(i in 1:(length(a)-1)){
      x1 <- a[i:(i+1)]
      y1 <- b[i:(i+1)]
      curve(y1[1]*(1-f((x-x1[1])/(x1[2]-x1[1]))) + y1[2]*f((x-x1[1])/(x1[2]-x1[1])), x1[1],x1[2], add = TRUE, ...)
    }
  }

  plotmix <- function(x, xlim = NULL, ylim = NULL, xlab = "Allele", ylab = "Peak height",
                      col = par("col"), bg = NA, pch = par("pch"), 
                      cex = par("cex"), lty = par("lty"), lwd = par("lwd"), 
                      axes = TRUE, frame.plot = axes, xaxt = par("xaxt"), yaxt = par("xaxt"),
                      ann = par("ann"), cex.lab = par("cex.lab"), 
                      col.lab = par("col.lab"), font.lab = par("font.lab"), 
                      cex.axis = par("cex.axis"), col.axis = par("col.axis"), 
                      font.axis = par("font.axis"),
                      main = NULL, col.main = par("col.main"), font.main = par("font.main"), cex.main = par("cex.main"),
                      ...){


    plotFun <- function(m, r){

      if (!add){ ## Start a new plot
        ylim <- if (is.null(ylim)) c(0,maxheight) else ylim
        xlim <- if (is.null(xlim)) range(pp[[m]][[r]]$x) else xlim
        main <- if (is.null(main)) m else main
        plot(0,0, type = "n", 
             xlab = xlab, ylab = ylab,
             main = main, ylim = ylim, xlim = xlim, axes = FALSE,
             col.main = col.main, font.main = font.main, cex.main = cex.main, ...)
        
        if (axes){
          ## Draw axes
          a <- x$data[[m]]$allele
          axis(1, at = a[a-floor(a) == 0], labels = as.integer(a[a-floor(a) == 0]), xaxt = xaxt, ...)
          axis(1, at = a[a-floor(a) != 0], labels = FALSE, tcl = par("tcl")*.5, xaxt = xaxt, ...)
          axis(2, yaxt = yaxt, ...)
        }
        if (frame.plot){
          ## Draw box around the plot
          box(...)
        } 
      }

      ## Could annotate with known profiles --- not implemented
      
      ## Peaks are drawn by the panel function (default smooth peaks)
      panel <- if (is.null(panel)) nicePeak ## else match.fun(panel)
      do.call(panel, list(pp[[m]][[r]]$x, pp[[m]][[r]]$y, col = col, lwd = lwd, lty = lty, ...))

      if (threshold){
        abline(h = x$C[[r]], lty = "22")
      }
    }
    
    for (r in traces){
      submarkers <- intersect(names(x$observed)[sapply(x$observed, function(o)r %in% o)], markers)
      
      if (plot.type == "epg" && length(traces) == 1){
        ## One row in the plot per dye
        dyes <- x$dyes[[r]]
        submarkers <- intersect(unlist(dyes), submarkers) ## should be in the order of dyes
        rs <- length(dyes) ## number of dyes
        cs <- max(sapply(dyes, length)) ## number of markers for a dye
        ind <- rep(0, rs*cs)
        l <- k <- 1
        for (i in 1:rs){
          for (j in 1:cs){
            if (j <= length(dyes[[i]])){
              if (dyes[[i]][j] %in% submarkers){
                ind[l] <- k
                k <- k+1
              }
            }
            l <- l+1
          }
        }
        layout(matrix(ind, nrow = rs, ncol = cs, byrow = TRUE))
      }
      for(m in submarkers){
        plotFun(m,r, ...)
      }
    }
    invisible(pp)
  }

  #if (plot.type == "multiple"){
  #  omi = c(0,0,0,0),         # No outer margin (inches)
  #  mar = c(2.5,2.5,1.5,0.5), # margin between plot- and figure-region. (lines)
  #  tcl = -0.2,               # tick-length (1=lineheight)
  #  mgp = c(1.3,.3,0)),       # position of axislabel, ticklabels and axis (lines)
  #  oldpar <- par(mar = mar, oma = oma)
  #  on.exit(par(oldpar))
  #}
  plotmix(x, ...)
}

##' QQ-plot for the distribution of observed peak heights.
##'
##' @export
##' @param x A DNAmixture model.
##' @param pars Model parameters.
##' @param dist Joint, conditional or prequential.
##' @param xlab Legend for the x-axis.
##' @param ylab Legend for y-axis.
##' @param xlim Range of x-axis. Default is a plot with equal ranges
##' on the x- and y-axis.
##' @param ylim Range of y-axis.
##' @param by.allele Order of conditioning when \code{dist = "prequential"}. See \code{\link{predict.DNAmixture}}
##' @param ... Other arguments for \code{plot}
##' @return A \code{data.frame} containg quantiles P(Z < z_obs | Z > 0) in the
##' specified model, together with other output from \code{predict.DNAmixture}.
##' @author Therese Graversen
##' @examples
##' data(MC15, MC18, USCaucasian)
##' mix <- DNAmixture(list(MC15, MC18), C = list(50, 38), k = 3, K = c("K1", "K3"), database = USCaucasian)
##' p <- mixpar(list(list(rho = 30, eta = 30, xi = 0.08, phi = c(U1 = 0.1, K3 = 0.2, K1 = 0.7)),
##'                  list(rho = 30, eta = 30, xi = 0.08, phi = c(U1 = 0.1, K3 = 0.2, K1 = 0.7))))
##' qq <- qqpeak(mix, pars = p, dist = "prequential")
qqpeak <- function(x, pars, dist = c("joint", "conditional", "prequential"),
                   by.allele = TRUE,
                   xlab = "Uniform quantiles", ylab = NULL, xlim = NULL, ylim = xlim, ...){
  dist <- match.arg(dist)
 
  if (is.null(ylab)){
    ylab <- switch(dist,
                   joint = expression(paste("P(", Z[a] <= z[a], " | ", Z[a] >= C,")")),
                   conditional = expression(paste("P(", Z[a] <= z[a], " | ", Z[b] == z[b], ", ", b!=a, ", ", Z[a] >= C,")")),
                   prequential = expression(paste("P(", Z[a] <= z[a], " | ", Z[b] == z[b], ", ", b<a, ", ", Z[a] >= C,")"))
                   )
  }
  
  d <- do.call("rbind", predict(x, pars = pars, dist = dist, by.allele = by.allele))
  rownames(d) <- NULL
  d <- subset(d, d$height > 0)
  d$q <- (d$smaller - d$unseen)/d$seen

  xs <- ppoints(d$q)
  ys <- sort(d$q)

  if (is.null(xlim)){xlim <- range(xs, ys)}
  plot(xs, ys,
       xlim = xlim, ylim = ylim,
       xlab = xlab, ylab = ylab, ...)
  invisible(d)
}


##' Plot simulated peak heights for multiple traces.
##'
##' A plot will be made for each combination of traces and markers
##' specified, and it is up to the user to specify a layout for the
##' plots (e.g. via calls to \code{\link{par}})
##'
##' @param x A multiple traces DNA mixture.
##' @param sims A set of simulated peak heights. See also \code{\link{rPeakHeight}}.
##' @param traces Selected traces to plot.
##' @param markers Selected markers to plot.
##' @param pw Peaks are 2*pw wide.
##' @param ylim Range of the y-axis.
##' @param border Color of the boxes.
##' @param ... Arguments passed on to \code{boxplot}.
##' @return Invisibly the peak heights as used for the boxplots. 
##' @author Therese Graversen
##' @S3method boxplot DNAmixture
##' @method boxplot DNAmixture
##' @importFrom graphics boxplot
##' @examples
##' data(MC15, MC18, USCaucasian)
##' mix <- DNAmixture(list(MC15, MC18), C = list(50, 38), k = 3, K = "K3", database = USCaucasian)
##' p <- mixpar(list(list(rho = 30, eta = 30, xi = 0.08, phi = c(U2 = 0.1, K3 = 0.2, U1 = 0.7)),
##'                  list(rho = 30, eta = 30, xi = 0.08, phi = c(U1 = 0.9, K3 = 0.05, U2 = 0.05))))
##' rpm <- rPeakHeight(mix, p, nsim = 50, dist = "joint")
##' rpc <- rPeakHeight(mix, p, nsim = 50, dist = "conditional")
##' par(mfrow = c(2,2))
##' boxplot(mix, rpm, traces = 1:2, markers = "VWA") ## First row of plots
##' boxplot(mix, rpc, traces = 1:2, markers = "VWA") ## Second row of plots
##' mixK <- DNAmixture(list(MC15, MC18), C = list(50, 38), k = 3, K = c("K1", "K2", "K3"),
##'                     database = USCaucasian)
##' pK <- mixpar(list(list(rho = 30, eta = 30, xi = 0.08, phi = c(K2 = 0.1, K3 = 0.2, K1 = 0.7)),
##'                  list(rho = 30, eta = 30, xi = 0.08, phi = c(K2 = 0.1, K3 = 0.2, K1 = 0.7))))
##' rpmK <- rPeakHeight(mixK, pK, nsim = 50)
##' boxplot(mixK, rpmK)
boxplot.DNAmixture <- function(x, sims, traces = 1:x$ntraces,
                               markers = x$markers, pw = 0.4, 
                               ylim = NULL, border = "grey", ...){

  if (is.null(ylim)){
    ## Largest peak height
    ylim <- c(0,max(sapply(markers, function(m)max(x$data[[m]][,traces+1], sims[[m]][traces,,], na.rm = TRUE))))
  }
  
  bp <- function(m, r){
    d <- x$data[[m]]
    a <- d$allele

    heights <- sims[[m]][r,,]
    # colors <- apply(heights, 1, function(x)ifelse(all(x == 0), "blue", "grey"))
    plot(x, markers = m, traces = r, ylim = ylim, ...)
    
    usr <- par("usr")
    for (i in seq_along(a)){
      clip(usr[1], usr[2], x$C[[r]], usr[4])
      boxplot(t(heights)[,i], at = a[i], add = TRUE, border = border)
    }
    do.call("clip", as.list(usr))  # reset to plot region

    ## Re-draw peaks on top
    plot(x, markers = m, traces = r, add = TRUE, ...)

    ## And points on top too
    points(a, d[, r+1],
           col = "red", pch = ifelse(d[,r+1] > 0, 4, 1), cex = 1.3)
    axis(1, at = a[a-floor(a) == 0], labels = as.integer(a[a-floor(a) == 0]))
    axis(1, at = a[a-floor(a) != 0], labels = FALSE)
  }

  for (r in traces) {
    for (m in markers){
      if (r %in% x$observed[[m]]) bp(m, r)
    }
  }

  invisible(sims)
}
