##' Set tables for binary nodes Q_a
##'
##' The function sets conditional probabilities for dummy nodes Q_a,
##' that are used for finding probabilities of observing a smaller or
##' larger peak, than the one specified in peak heights for the DNA mixture.
##' The cpts are defined as
##' \deqn{P(Q_a = TRUE | allelecounts) = P(Z_a < height_a| allelecounts)}
##'
##' @export
##' 
##' @param domain A \code{hugin.domain} modelling one marker
##' @param rho rho
##' @param xi xi
##' @param eta eta
##' @param phi phi ordered as \eqn{phi_{U,K}}.
##' @param heights Observed peak heights
##' @param n.unknown Number of unknown contributors
##' @param n_K Allelecounts for known contributors
##' @param Q Names for binary nodes
##' @param gets_stutter Does the allele receive stutter?
##' @param can_stutter Can the allele stutter?
##' @param stutter.from From which allele does the stutter come?
##' @return Scaling factors to be set as evidence when conditioning on the peak heights
##' @author Therese Graversen
##' @seealso For further details see \code{\link{set.CPT.O}}.
set.CPT.Q <- function(domain, rho, xi, eta, phi, heights, n.unknown,
                      n_K, Q, gets_stutter, can_stutter, stutter.from){

  ## Combinations of allele counts for one allele all contributors.
  n_U <- expand.grid(rep(list(0:2), n.unknown), KEEP.OUT.ATTRS = FALSE)
  
  one.allele <- function(a){

    ## Find shape parameters 
    ## Contribution from allele a
    n_a <- as.matrix(merge(n_U, n_K[a,])) ## = n_U if n_K is NULL
    shapes <- rho * (1 - xi*can_stutter[a]) * (n_a %*% phi)
    
    if (gets_stutter[a]){
      ## Adding contributions from stutter from allele b
      ## Using "can_stutter" must be redundant...
      b <- stutter.from[a]
      n_b <- as.matrix(merge(n_U, n_K[b,])) ## using n_Ua = n_Ub
      newshapes <- rho * xi*can_stutter[b] * (n_b %*% phi)
      
      shapes <- outer(shapes, newshapes, "+")
    }
    shapes <- as.vector(shapes)

    p.shorter <- pgamma(heights[a], shape = shapes, scale = eta)
    p.higher <- pgamma(heights[a], shape = shapes, scale = eta, lower.tail = FALSE)

    ## CPT alternates Q_a = FALSE and Q_a = TRUE between each row
    ## starting from Q_a = FALSE
    cptfreqs <- as.numeric(rbind(p.higher, p.shorter)) 
    set.table(domain, Q[a], cptfreqs, type = "cpt")
  }
  sapply(seq_along(Q), one.allele)
  invisible(NULL)
}
