##' Dyes for a DNA mixture
##'
##' @param mixture A DNA mixture 
##' @return The dyes used for the DNA mixture
##' @export
##' @seealso \code{\link{DNAmixture}}
dyes <- function(mixture){
  mixture$dyes
}

##' @rdname dyes
##' @usage dyes(mixture) <- value
##' @param value A list with one item per dye, each containing a vector of marker names.
##' @export
"dyes<-" <- function(mixture, value){
  if (length(value) != mixture$ntraces) stop("Number of dyes does not match number of traces")
  mixture$dyes <- value
  mixture
}
